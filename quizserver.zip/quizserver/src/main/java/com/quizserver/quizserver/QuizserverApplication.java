package com.quizserver.quizserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizserverApplication.class, args);
	}

}
