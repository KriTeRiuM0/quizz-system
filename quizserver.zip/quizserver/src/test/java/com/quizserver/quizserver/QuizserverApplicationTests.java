package com.quizserver.quizserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
